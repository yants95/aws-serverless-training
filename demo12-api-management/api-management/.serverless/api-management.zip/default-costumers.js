const privateUsers = async () => {
    return [
        'yan@gmail.com',
        'thais@gmail.com',
        'pudim@gmail.com'
    ]
}

exports.private = privateUsers