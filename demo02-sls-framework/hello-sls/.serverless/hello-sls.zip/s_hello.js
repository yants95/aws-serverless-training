
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'yts1995',
  applicationName: 'hello-sls-app',
  appUid: 'cyxs57C4NdTWy9NmGZ',
  orgUid: '41fe818c-3208-4097-a19f-4e993a719c6e',
  deploymentUid: '74d34e23-cb53-4a3c-b756-5374601bd85a',
  serviceName: 'hello-sls',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.4.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'hello-sls-dev-hello', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}